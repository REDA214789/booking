Spring Web Flow Samples
=======================

This is the official samples repository for the [Spring Web Flow](https://github.com/SpringSource/spring-webflow) project.

From a sample sub-directory, use `mvn jetty:run` to run a server, or `mvn package` to build a war.

